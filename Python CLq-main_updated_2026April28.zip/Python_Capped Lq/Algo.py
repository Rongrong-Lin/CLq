import numpy as np


def PGAC(A, b, mu, shrinkage, a, Lambda, maxiter, x_true=None):
    n = A.shape[1]
    x0 = np.zeros((n, 1))
    AT = A.T 
    rel_errors = []
    record_error = x_true is not None
    if record_error:
        norm_x_true = np.linalg.norm(x_true)
        
    for i in range(maxiter):
        # 抛弃 O(n^2) 的大矩阵相乘，改为 O(mn) 的链式相乘
        grad = AT @ (A @ x0 - b)
        x1 = x0 - mu * grad  
        x = shrinkage(x1, a, mu * Lambda)
        x0 = x
        if record_error:
            rel_error = np.linalg.norm(x - x_true) / norm_x_true
            rel_errors.append(rel_error)       
        if Lambda < 1e-4:
            break
        Lambda *= 0.98
        
    if record_error:
        return x, i+1, rel_errors
    else:
        return x, i+1
# def PGAC(A, b, mu, shrinkage, a, Lambda, maxiter, x_true=None):
#     x0 = np.zeros((A.shape[1], 1))
#     aa = np.eye(A.shape[1]) - (mu * A.T.dot(A))
#     ab = mu * A.T.dot(b)
#     # 初始化误差记录
#     rel_errors = []
#     record_error = x_true is not None
#     for i in range(maxiter):
#         # 梯度步
#         x1 = aa.dot(x0) + ab
#         # 临近算子步
#         x = shrinkage(x1, a, mu * Lambda)
#         x0 = x.copy()
#         # 记录误差(如果提供了x_true)
#         if record_error:
#             rel_error = np.linalg.norm(x - x_true) / np.linalg.norm(x_true)
#             rel_errors.append(rel_error)
#         #终止条件
#         if Lambda < 1e-4:
#             break
#         # 衰减Lambda
#         Lambda = 0.98 * Lambda
#     if record_error:
#         return x, i+1, rel_errors
#     else:
#         return x, i+1


def IRL1_CLq(A, b, mu, q, Lambda, theta, epsilon, maxiter, x_true=None):
    """
    Lambda: 截断阈值 λ
    theta: 权重公式中的系数 θ
    epsilon: 权重公式中的平滑常数 ε
    """
    n = A.shape[1]
    x0 = np.zeros((n, 1))
    # 预计算梯度步需要的矩阵，减少运算量
    # x_new = x - mu * A.T @ (A @ x - b) -> (I - mu*A.T@A)x + mu*A.T@b
    aa = np.eye(n) - (mu * A.T.dot(A))
    ab = mu * A.T.dot(b)
    rel_errors = []
    record_error = x_true is not None
    
    for i in range(maxiter):
        # 1. 计算权重向量 w (根据图片公式)
        abs_x = np.abs(x0)
        weights = np.zeros((n, 1))
        # 分段逻辑：|x| < Lambda 时计算权重，否则为 0
        mask = abs_x < Lambda
        weights[mask] = (theta * q / (Lambda**q)) * (abs_x[mask] + epsilon)**(q - 1)
        # weights[~mask] = 0  # 已经是0了
        # 2. 梯度步
        z = aa.dot(x0) + ab 
        # 3. 带权重的近端算子步 (软阈值)
        # 注意：这里的阈值是 mu * w_i
        threshold = mu * weights
        x_new = np.sign(z) * np.maximum(np.abs(z) - threshold, 0)
        # 记录误差
        if record_error:
            rel_error = np.linalg.norm(x_new - x_true) / np.linalg.norm(x_true)
            rel_errors.append(rel_error)
        #收敛判断
        if np.linalg.norm(x_new - x0) / (np.linalg.norm(x_new) + 1e-9) < 1e-6:
            x0 = x_new.copy()
            break    
        x0 = x_new.copy()

    if record_error:
        return x0, i + 1, rel_errors
    else:
        return x0, i + 1

def Error(x, x_true):# Calculate the Error
    return (np.linalg.norm(x-x_true)/np.linalg.norm(x_true))
