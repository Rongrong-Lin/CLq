import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.linalg import orth
from time import perf_counter
#from Algo import PGAC
#from prox import shrinkage_CaP1over2, shrinkage_CaP1over2_chen

    
def PGAC(A, b, mu, shrinkage, a, Lambda, maxiter, x_true=None):
    n = A.shape[1]
    x0 = np.zeros((n, 1))
    AT = A.T 
    rel_errors = []
    record_error = x_true is not None
    if record_error:
        norm_x_true = np.linalg.norm(x_true)
        
    for i in range(maxiter):
        # 抛弃 O(n^2) 的大矩阵相乘，改为 O(mn) 的链式相乘
        grad = AT @ (A @ x0 - b)
        x1 = x0 - mu * grad  
        x = shrinkage(x1, a, mu * Lambda)
        x0 = x
        if record_error:
            rel_error = np.linalg.norm(x - x_true) / norm_x_true
            rel_errors.append(rel_error)       
        if Lambda < 1e-4:
            break
        Lambda *= 0.98
        
    if record_error:
        return x, i+1, rel_errors
    else:
        return x, i+1


# CL1/2 shrinkage-chen
def J_cost_CL1over2(u, tau, a, nu):
    """
    辅助函数：计算目标代价函数 J_tau(u)
    u: 候选解 (取绝对值后)
    tau: 原始输入向量 (取绝对值后)
    a: 截断阈值 
    nu: 惩罚系数 
    """
    # 当 u >= a 时，惩罚项达到上限 nu
    penalty = np.where(u < a, (nu / np.sqrt(a)) * np.sqrt(u), nu)
    
    return penalty + 0.5 * (u - tau)**2

def shrinkage_CaP1over2_chen(x, a, nu):
    """
    基于 Chen 等人推导式的 Capped L1/2 邻近算子
    """
    tau_abs = np.abs(x)
    sign_x = np.sign(x)
    
    # 1. 计算基础 L1/2 Prox 的解
    weight = nu / np.sqrt(a)
    z = ProxL1over2_array(weight, tau_abs)
    
    # 2. 构造候选解
    # 候选 1: z (属于集合 S 的前提是 z < \lambda)
    # 候选 2: max(|\tau|, \lambda)
    c1 = z.copy()
    c2 = np.maximum(tau_abs, a)
    
    # 3. 计算各个候选解的代价函数 J_tau(u)
    J1 = J_cost_CL1over2(c1, tau_abs, a, nu)
    # 如果 z >= a，则不满足集合 S 的条件 z < \lambda，将其代价设为无穷大排除
    J1[c1 >= a] = np.inf 
    
    J2 = J_cost_CL1over2(c2, tau_abs, a, nu)
    
    # 4. 比较并选择代价最小的解 (arg min)
    res_abs = np.where(J1 <= J2, c1, c2)
    
    # 恢复原始符号并返回
    return res_abs * sign_x


# CL1/2 shrinkage
# 预计算常数，避免在函数内重复计算
C_PROX_CONST = (3 * math.sqrt(3)) / 4 

def J_scalar(q, nu, Lambda, u, tau):
    """纯标量版本的 J 函数"""
    val = abs(u) / Lambda
    # np.minimum 的标量替代
    term1 = val ** q if val < 1.0 else 1.0
    return nu * term1 + 0.5 * (u - tau) ** 2

def ProxL1over2_scalar(nu, tau):
    """纯标量版本的 ProxL1over2，专供二分法使用"""
    abs_tau = abs(tau)
    threshold = 1.5 * (nu ** (2/3))
    
    if abs_tau > threshold:
        # 使用 math 库替代 numpy，标量运算更快
        theta = math.acos(-C_PROX_CONST * nu * (abs_tau ** -1.5))
        return (2 / 3) * tau * (1 + math.cos((2 * theta) / 3))
    return 0.0

def bisection_CL1over2_opt(a, b, q, nu, Lambda):
    """优化后的二分法，减少了 50% 的函数调用"""
    nu_scaled = nu / (Lambda ** q)   
    # 缓存端点 a 的函数值，避免在循环中重复计算
    u_a = ProxL1over2_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL1over2_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu      
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc  # 更新缓存的 fa，避免下次重新计算 a
        if (b - a) < 1e-5:
            break
    return (a + b) / 2


def ProxL1over2_array(nu, tau):
    """优化后的数组版本，供最终矩阵收缩使用"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 1.5 * (nu ** (2/3))
    condition = abs_tau > threshold
    # 如果没有满足条件的元素，直接返回全零，节省时间
    if not np.any(condition):
        return ytilde
    tau_cond = tau[condition]
    abs_tau_cond = abs_tau[condition]
    theta = np.arccos(-C_PROX_CONST * nu * (abs_tau_cond ** -1.5))
    ytilde[condition] = (2 / 3) * tau_cond * (1 + np.cos((2 * theta) / 3))
    return ytilde

def shrinkage_CaP1over2(x0, Lambda, nu):
    """优化后的主函数"""
    x = x0.copy() 
    sqrt_Lambda = math.sqrt(Lambda)
    nu_scaled = nu / sqrt_Lambda
    cnulambda_1over2 = 1.5 * (nu_scaled ** (2/3))
    # q=0.5 已经硬编码在调用中
    C_nulambda_1over2 = bisection_CL1over2_opt(
        cnulambda_1over2, 
        Lambda + 0.5 * nu / Lambda, 
        0.5, 
        nu, 
        Lambda
    )
    # 只需计算一次索引
    index0 = np.abs(x0) < C_nulambda_1over2
    x[index0] = ProxL1over2_array(nu_scaled, x0[index0])
    return x

# ==================== 参数设置 ====================
m = 256  # 测量数
n = 1024  # 信号维度
k = 82 # 目标稀疏度（非零元素数）
#k=10,20,31,41,51,61,72,82,92,102,113,123,133
maxiter = 500  # 最大迭代次数
np.random.seed(100)
# ==================== 测量矩阵生成 ====================
print("生成测量矩阵...")
Q = np.random.normal(0, 1, (m, n))
#A = Q / np.linalg.norm(Q, axis=0).reshape(1, -1)
A = orth(Q.T).T
#e = np.linalg.eigvals(A @ A.T)
#print('最大特征值：', max(e).real)

# ==================== 算子参数设置 ====================
names = ['Capped1over2', 'Capped1over2-Chen']
shrinkage_list = [shrinkage_CaP1over2, shrinkage_CaP1over2_chen]
a = 2
# ==================== 生成真实信号 ====================
print("生成稀疏信号...")
sigma = 0.001  # 噪声水平 σ = 0.1% = 0.001
x_true = np.zeros((n, 1))
nonzero_indices = np.random.choice(n, size=k, replace=False)
x_true[nonzero_indices] = np.random.randn(k, 1)  # 非零值为高斯分布
#x_true[x_true != 0] = 5 * x_true[x_true != 0]
epsilon = sigma * np.random.randn(m, 1)
b = A @ x_true + epsilon
lamb = np.linalg.norm(x_true)/(np.sqrt(k) + 1)
print('lamb:',lamb)
mu = 1

# ==================== 记录误差历史 ====================
error_history = {name: [] for name in names}  # 初始化字典存储各算子的误差
time_history = {name: 0.0 for name in names}  # 记录各算法总耗时(秒)

# ==================== 主实验循环 ====================
print("运行各算子...")
for i, name in enumerate(names):
    print(f"正在运行{name}...")
    shrinkage = shrinkage_list[i]
    t0 = perf_counter()
    x_rec, iter_count, rel_errors = PGAC(A, b, mu, shrinkage, a, lamb, maxiter, x_true)
    t1 = perf_counter()

    # 记录误差
    error_history[name] = rel_errors
    time_history[name] = t1 - t0
    print(f"{name} 耗时: {time_history[name]:.6f} s, 迭代: {iter_count}")
    

print("=== 时间统计 ===")
for name in names:
    print(f"{name}: {time_history[name]:.6f} s")


# ==================== 绘图 ====================
print("绘制收敛曲线...")
plt.figure(figsize=(12, 8))
color_list = ['red', 'blue']
label_list = [
    "PGAC_CL1/2",
    "Pan and Chen_CL1/2"
]
mark_list = ['^',None]
for i, name in enumerate(names):
    plt.plot(range(len(error_history[name])), error_history[name],
         color=color_list[i],
         linewidth=2.5,
         linestyle='--',
         marker=mark_list[i],
         markersize=12 if mark_list[i] else 0,
         markevery=0.1,
         label=label_list[i])

plt.yscale('log')
plt.xlabel('Iteration', fontsize=18)
plt.ylabel('Relative Error', fontsize=18)
plt.legend(fontsize=14, loc='upper right')
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.tight_layout()

# 保存图像
#timestamp = time.strftime("%Y%m%d-%H%M%S")
percent = round(k / n * 100)  # 四舍五入到整数
plt.savefig(f'sparsity={percent}_percent_chen.png', dpi=300, bbox_inches='tight')
plt.show()
