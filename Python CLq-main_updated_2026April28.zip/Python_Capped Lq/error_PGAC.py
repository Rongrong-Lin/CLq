import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import orth
from prox import *
from Algo import PGAC
# ==================== 参数设置 ====================
m = 256  # 测量数
n = 1024  # 信号维度
k = 51 # 目标稀疏度（非零元素数）
#k=10,20,31,41,51,61,72,82,92,102,113,123,133
maxiter = 500  # 最大迭代次数
np.random.seed(100)
# ==================== 测量矩阵生成 ====================
print("生成测量矩阵...")
Q = np.random.normal(0, 1, (m, n))
#A = Q / np.linalg.norm(Q, axis=0).reshape(1, -1)
A = orth(Q.T).T
e = np.linalg.eigvals(A @ A.T)
print('最大特征值：', max(e).real)

# ==================== 算子参数设置 ====================
shrinkage_list = [
    shrinkage_CaP1over4,  # 0: CL1/4
    shrinkage_CaP1over3,  # 1: CL1/3
    shrinkage_CaP1over2,  # 2: CL1/2
    shrinkage_CaP2over3,  # 3：CL2/3
    shrinkage_CaP3over4,  # 4: CL3/4
    shrinkage_CaP1,  # 5: CL1
    shrinkage_l1over4, # 6: L1/4
    shrinkage_l1over3, # 7: L1/3
    shrinkage_l1over2, # 8: L1/2
    shrinkage_l2over3, # 9: L2/3
    shrinkage_l3over4, # 10: L3/4
    shrinkage_l1, # 11: L1
    shrinkage_log_soft, # 12: Log
    shrinkage_TL1, # 13: TL1
    shrinkage_scad, # 14: SCAD
    shrinkage_mcp, # 15: MCP
    shrinkage_PiE_soft, # 16: PiE
]


a_list = [  2,      2,      2,      2,      2,     2,     0,     0,     0,    0,      0,    0,    1,    2,   3.7,   3.7,   2  ]
names = ["CL1/4","CL1/3","CL1/2","CL2/3","CL3/4","CL1", "L1/4","L1/3","L1/2","L2/3","L3/4","L1","Log","TL1","SCAD","MCP","PiE"]


# ==================== 生成真实信号 ====================
print("生成稀疏信号...")
sigma = 0.001  # 噪声水平 σ = 0.1% = 0.001
x_true = np.zeros((n, 1))
nonzero_indices = np.random.choice(n, size=k, replace=False)
x_true[nonzero_indices] = np.random.randn(k, 1)  # 非零值为高斯分布
#x_true[x_true != 0] = 2 * x_true[x_true != 0]
epsilon = sigma * np.random.randn(m, 1)
b = A @ x_true + epsilon
lamb = np.linalg.norm(x_true)/(np.sqrt(k) + 1)
print('lamb:',lamb)
mu = 1

# ==================== 记录误差历史 ====================
error_history = {name: [] for name in names}  # 初始化字典存储各算子的误差

# ==================== 主实验循环 ====================
print("运行各算子...")
for i, shrinkage in enumerate(shrinkage_list):
    name = names[i]
    print(f"正在运行{name}...")

    a = a_list[i]
    
    # 使用PGAC算法
    x_rec, iter_count, rel_errors = PGAC(A, b, mu, shrinkage, a, lamb, maxiter, x_true)

    # 记录误差
    error_history[name] = rel_errors


# ==================== 绘图 ====================
print("绘制收敛曲线...")
plt.figure(figsize=(12, 8))
color_list = ['red', 'blue', 'green', 'orange', 'purple', 'chocolate', 'deeppink', 'gold', 'navy', 'maroon','cyan', 'teal',
              'pink', 'lawngreen', 'slategray', 'orchid', 'skyblue']
label_list = names
mark_list = ['^','^','^','^','^',None,None,None,None,None,None,None,None,None,None,None,None]
for i, name in enumerate(names):
    if error_history[name]:
        plt.plot(range(len(error_history[name])), error_history[name],
                color=color_list[i],
                linewidth=2.5,
                linestyle='--',
                marker=mark_list[i],
                markersize=12 if mark_list[i] else 0,
                markevery=0.1,
                label=label_list[i])  
                     
            
plt.yscale('log')
plt.xlabel('Iteration', fontsize=18)
plt.ylabel('Relative Error', fontsize=18)
plt.legend(fontsize=14, bbox_to_anchor=(1.01, 1), loc='upper left', borderaxespad=0)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.tight_layout()

# 保存图像
#timestamp = time.strftime("%Y%m%d-%H%M%S")
percent = round(k / n * 100)  # 四舍五入到整数
plt.savefig(f'sparsity={percent}_percent_PGAC.png', dpi=500, bbox_inches='tight')
plt.show()
