import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import orth
from time import perf_counter
from prox_fast import *
from Algo import PGAC, IRL1_CLq
# ==================== 参数设置 ====================
m = 256  # 测量数
n = 1024  # 信号维度
k = 20 # 目标稀疏度（非零元素数）
#k=10,20,31,41,51,61,72,82,92,102,113,123,133
maxiter = 3000  # 最大迭代次数
np.random.seed(100)
# ==================== 测量矩阵生成 ====================
print("生成测量矩阵...")
Q = np.random.normal(0, 1, (m, n))
#A = Q / np.linalg.norm(Q, axis=0).reshape(1, -1)
A = orth(Q.T).T
e = np.linalg.eigvals(A @ A.T)
print('最大特征值：', max(e).real)

# ==================== 算子参数设置 ====================
pgac_shrinkage_list = [
    shrinkage_CaP1over4,  # CL1/4
    shrinkage_CaP1over3,  # CL1/3
    shrinkage_CaP1over2,  # CL1/2
    shrinkage_CaP2over3,  # CL2/3
    shrinkage_CaP3over4,  # CL3/4
]
a_list = [2, 2, 2, 2, 2]
pgac_names = ["PGAC_CL1/4", "PGAC_CL1/3", "PGAC_CL1/2", "PGAC_CL2/3", "PGAC_CL3/4"]

q_list = [0.25, 1/3, 0.5, 2/3, 0.75]
# 每个 q 的专属超参数: (lambda, theta, eps)
irl1_param_map = {
    0.25: {"lamb": 2.0, "theta": 0.005, "eps": 5e-2},  
    1/3:  {"lamb": 2.0, "theta": 0.0045,  "eps": 5e-2},  
    0.5:  {"lamb": 2.0, "theta": 0.004,  "eps": 5e-2},    
    2/3:  {"lamb": 2.0, "theta": 0.0035,  "eps": 5e-2},  
    0.75: {"lamb": 2.0, "theta": 0.003,  "eps": 5e-2},  
}

irl1_names = ["pIRL1_CL1/4", "pIRL1_CL1/3", "pIRL1_CL1/2", "pIRL1_CL2/3", "pIRL1_CL3/4"]

names = pgac_names + irl1_names

# ==================== 生成真实信号 ====================
print("生成稀疏信号...")
sigma = 0.001  # 噪声水平 σ = 0.1% = 0.001
x_true = np.zeros((n, 1))
nonzero_indices = np.random.choice(n, size=k, replace=False)
x_true[nonzero_indices] = np.random.randn(k, 1)  # 非零值为高斯分布
#x_true[x_true != 0] = 2 * x_true[x_true != 0]
epsilon = sigma * np.random.randn(m, 1)
b = A @ x_true + epsilon
mu = 1

# ==================== 记录误差历史 ====================
error_history = {name: [] for name in names}  # 初始化字典存储各算子的误差
timing_history = {name: 0.0 for name in names}  # 初始化字典存储各算子的耗时

# ==================== 主实验循环 ====================
print("运行各算子...")

# 1) 先跑 PGAC 的 5 条曲线
for i, shrinkage in enumerate(pgac_shrinkage_list):
    name = pgac_names[i]
    print(f"正在运行{name}...")

    lamb = np.linalg.norm(x_true) / (np.sqrt(k) + 1)
    a = a_list[i]
    
    t_start = perf_counter()
    x_rec, iter_count, rel_errors = PGAC(A, b, mu, shrinkage, a, lamb, maxiter, x_true)
    t_end = perf_counter()
    error_history[name] = rel_errors
    timing_history[name] = t_end - t_start

# 2) 再跑 IRL1 的 5 条曲线
for j, q_val in enumerate(q_list):
    name = irl1_names[j]
    print(f"正在运行{name}...")

    p = irl1_param_map[q_val]
    lamb = p["lamb"]
    theta_val = p["theta"]
    eps_val = p["eps"]

    t_start = perf_counter()
    x_rec, iter_count, rel_errors = IRL1_CLq(A, b, mu, q_val, lamb, theta_val, eps_val, maxiter, x_true)
    t_end = perf_counter()
    error_history[name] = rel_errors
    timing_history[name] = t_end - t_start

print("\n========== 算法耗时汇总 ==========")
for name in names:
    print(f"{name}: {timing_history[name]:.6f} s")
print("==================================\n")


# ==================== 绘图 ====================
print("绘制收敛曲线...")
plt.figure(figsize=(12, 8))
color_list = [
    'red', 'blue', 'green', 'orange', 'purple',
    'pink', 'lawngreen', 'slategray', 'orchid', 'skyblue']#, 'lawngreen', 'slategray', 'orchid', 'skyblue' , 'navy'        

label_list = names
mark_list = ['^','^','^','^','^',None,None,None,None,None]  
for i, name in enumerate(names):
    if error_history[name]:  # 确保有数据
        plt.plot(range(len(error_history[name])), error_history[name],
                     color=color_list[i],
                     linewidth=2.5,
                     linestyle='--',
                     marker=mark_list[i],
                     markersize=12 if mark_list[i] else 0,
                     markevery=0.1,
                     label=label_list[i])

plt.yscale('log')
plt.xlabel('Iteration', fontsize=18)
plt.ylabel('Relative Error', fontsize=18)
plt.legend(fontsize=14, loc='upper right')
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.tight_layout()

# 保存图像
#timestamp = time.strftime("%Y%m%d-%H%M%S")
percent = round(k / n * 100)  # 四舍五入到整数
plt.savefig(f'sparsity={percent}_percent_pIRL1.png', dpi=300, bbox_inches='tight')
plt.show()
