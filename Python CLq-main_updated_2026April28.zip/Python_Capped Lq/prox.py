import numpy as np
from scipy.special import lambertw


# log shrinkage
def q(Lambda, z, x, epsilon):
    return 1 / (2 * Lambda) * (x - z) ** 2 + np.log(1 + abs(x) / epsilon)

def r(z, Lambda, epsilon):
    return q(Lambda, z, r2(z, epsilon, Lambda), epsilon) - q(Lambda, z, 0, epsilon)

def r2(z, epsilon, Lambda):
    inner = 0.25 * (z + epsilon) ** 2 - Lambda
    return 0.5 * (z - epsilon) + np.sqrt(np.maximum(inner,0))

def bisection_lg(a, b, Lambda, epsilon):
    for i in range(30):
        c = (a + b) / 2
        if r(a, Lambda, epsilon) * r(c, Lambda, epsilon) < 0:
            b = c
        else:
            a = c
        if (b - a) < 1e-8:
            break
    return c

# def zstar(epsilon, Lambda):
#     return bisection_lg(2 * np.sqrt(Lambda) - epsilon, Lambda / epsilon, Lambda, epsilon)

def shrinkage_log_soft(x0, epsilon, Lambda):
    x = np.zeros((x0.shape[0], 1))
    index1 = abs(x0) > Lambda / epsilon
    x[index1] = np.sign(x0[index1]) * r2(abs(x0[index1]), epsilon, Lambda)
    return x

def shrinkage_log_hard(x0, epsilon, Lambda):
    z_star = bisection_lg(2 * np.sqrt(Lambda) - epsilon, Lambda / epsilon, Lambda, epsilon)
    x = np.zeros((x0.shape[0], 1))
    index1 = abs(x0) > z_star
    x[index1] = np.sign(x0[index1]) * r2(abs(x0[index1]), epsilon, Lambda)
    return x

def shrinkage_log(a_log, Lambda):
    if np.sqrt(Lambda) <= a_log:
        return shrinkage_log_soft
    else:
        return shrinkage_log_hard

# TL1 shrinkage
def tau(a, Lambda):
    if Lambda <= a**2 / (2 * (a + 1)):
        t = Lambda * (a + 1) / a
    else:
        t = np.sqrt(2 * Lambda * (a+1))- a / 2
    return t

def varphi(x0, a, Lambda):
    return np.arccos(1 - 27 * Lambda * a * (a + 1) / (2 * (a + abs(x0)) ** 3))

def shrinkage_TL1(x0, a, Lambda):
    x = np.zeros((x0.shape[0], 1))
    t= tau(a, Lambda)
    index0 = abs(x0) > t
    abs_x0 = abs(x0[index0])
    varphi_val = varphi(x0[index0], a, Lambda)
    x[index0] = np.sign(x0[index0]) * (
            (2 / 3) * (a + abs_x0) * np.cos(varphi_val / 3) - 2 * a / 3 + abs_x0 / 3)
    return x


# scad shrinkage
#此处nu和a是形状参数，Lambda是邻近算子参数
def shrinkage_scad(x0, a, Lambda):
    x = np.zeros((x0.shape[0], 1))
    nu = 1
    index1 = np.logical_and(Lambda*nu < np.abs(x0), np.abs(x0) <= nu*(Lambda + 1))
    index2 = np.logical_and(nu*(Lambda + 1) < np.abs(x0), np.abs(x0) <= a*nu)
    index3 = np.abs(x0) > a*nu
    x[index1] = x0[index1] - nu*Lambda*np.sign(x0[index1])
    x[index2] = ((a-1)*abs(x0[index2]) - a*nu*Lambda)*np.sign(x0[index2])/(a-1-Lambda)
    x[index3] = x0[index3]
    return x


# mcp shrinkage
#此处a是形状参数，Lambda是邻近算子参数，Lambda应比a小
def shrinkage_mcp(x0, a, Lambda):
    x = np.zeros((x0.shape[0], 1))
    index1 = np.logical_and(abs(x0) > Lambda, abs(x0) <= a)
    index2 = abs(x0) > a
    x[index1] = np.sign(x0[index1]) * (abs(x0[index1]) - Lambda) * a / (a - Lambda)
    x[index2] = x0[index2]
    return x


# PiE shrinkage
def P(z, mu_Lambda, sigma):
    return 0.5 + mu_Lambda * ((z / sigma + 1) * np.exp(-z / sigma) - 1) / (z ** 2)

def bisection_PiE(a, b, mu_Lambda, sigma):
    for i in range(30):
        c = (a + b) / 2
        if P(a, mu_Lambda, sigma) * P(c, mu_Lambda, sigma) < 0:
            b = c
        else:
            a = c
        if (b - a) < 1e-8:
            break
    return c

def PiEProximalbyLambertWThreshold(x0, sigma, mu_Lambda):
    x = np.zeros((x0.shape[0], 1))
    xstar = bisection_PiE(1e-5, np.sqrt(2 * mu_Lambda)-1e-5, mu_Lambda, sigma)
    threshold = xstar + mu_Lambda / sigma * np.exp(-xstar / sigma)######修改########
    index = abs(x0) > threshold
    z = -(mu_Lambda / sigma ** 2) * np.exp(-abs(x0[index]) / sigma)
    lamb = lambertw(z, 0).real
    x[index] = np.sign(x0[index]) * (sigma * lamb + abs(x0[index]))
    return x

def shrinkage_PiE_soft(x0, sigma, mu_Lambda):
    x = np.zeros((x0.shape[0], 1))
    index = abs(x0) > mu_Lambda / sigma
    z = -(mu_Lambda / sigma ** 2) * np.exp(-abs(x0[index]) / sigma)
    x1 = sigma * lambertw(z, 0).real + abs(x0[index])
    x[index] = np.sign(x0[index]) * x1
    return x

def shrinkage_PiE(a_pie, Lambda):
    threshold = Lambda / a_pie ** 2
    if threshold <= 1:
        return shrinkage_PiE_soft
    else:
        return PiEProximalbyLambertWThreshold


##############################  Lambda形状参数；nu邻近算子参数；tau输入向量  ##############################
#########################  CL1：lambda^2/nu>0.5；CL1/2&2/3：lambda^2/nu>=1.5  ########################
# CL1 shrinkage
def shrinkage_CaP1(x0, Lambda, nu):
    x = np.zeros((x0.shape[0], 1))
    index0 = np.logical_and(nu/Lambda<abs(x0),abs(x0) <= Lambda+nu/(2*Lambda))
    index1 = abs(x0) > Lambda+nu/(2*Lambda)
    x[index0] = x0[index0]-np.sign(x0[index0])*nu/Lambda
    x[index1] = x0[index1]
    return x


# CL1/2 shrinkage-chen
def J_cost_CL1over2(u, tau, a, nu):
    """
    辅助函数：计算目标代价函数 J_tau(u)
    u: 候选解 (取绝对值后)
    tau: 原始输入向量 (取绝对值后)
    a: 截断阈值 
    nu: 惩罚系数 
    """
    penalty = np.where(u < a, (nu / np.sqrt(a)) * np.sqrt(u), nu)
    return penalty + 0.5 * (u - tau)**2

def shrinkage_CaP1over2_chen(x, a, nu):
    """
    基于 Chen 等人推导式的 Capped L1/2 邻近算子
    """
    tau_abs = np.abs(x)
    sign_x = np.sign(x)
    
    # 1. 计算基础 L1/2 Prox 的解
    # 传入 ProxL1over2 的权重应为 \nu / \lambda^{1/2}
    weight = nu / np.sqrt(a)
    z = ProxL1over2(weight, tau_abs)
    
    # 2. 构造候选解
    # 候选 1: z (属于集合 S 的前提是 z < \lambda)
    # 候选 2: max(|\tau|, \lambda)
    c1 = z.copy()
    c2 = np.maximum(tau_abs, a)
    
    # 3. 计算各个候选解的代价函数 J_tau(u)
    J1 = J_cost_CL1over2(c1, tau_abs, a, nu)
    # 如果 z >= a，则不满足集合 S 的条件 z < \lambda，将其代价设为无穷大排除
    J1[c1 >= a] = np.inf 
    
    J2 = J_cost_CL1over2(c2, tau_abs, a, nu)
    
    # 4. 比较并选择代价最小的解 (arg min)
    res_abs = np.where(J1 <= J2, c1, c2)
    
    # 恢复原始符号并返回
    return res_abs * sign_x


# CL1/2 shrinkage
def J(q,nu,Lambda,u,tau):
    return nu*np.minimum(1.0,np.power(np.abs(u)/Lambda,q)) + 0.5 * (u -tau)**2

def ProxL1over2(nu, tau):
    ytilde = np.zeros_like(tau)
    condition = np.abs(tau) > 1.5 * np.power(nu, 2 / 3)
    theta = np.arccos((-np.power(3, 3 / 2) / 4) * nu * np.power(abs(tau[condition]), -3 / 2))
    ytilde[condition] = (2 / 3) * tau[condition] * (1 + np.cos((2 * theta) / 3))
    return ytilde

def bisection_CL1over2(a,b,q,nu,Lambda):
    for i in range(20):
        c=(a+b)/2
        if (J(q,nu,Lambda,ProxL1over2(nu/Lambda**q,a),a)-nu) * (J(q,nu,Lambda,ProxL1over2(nu/Lambda**q,c),c)-nu)<0:
            b=c
        else:
            a=c
        if (b-a)<1e-5:
            break
    return c

def shrinkage_CaP1over2(x0,Lambda,nu):
    x = np.zeros((x0.shape[0], 1))
    cnulambda_1over2 = (3 / 2) * np.power(nu / np.power(Lambda, 1 / 2), 2 / 3)
    C_nulambda_1over2 = bisection_CL1over2(cnulambda_1over2, Lambda + (1 / 2) * nu / Lambda, 1 / 2, nu, Lambda)
    index0 = abs(x0) < C_nulambda_1over2
    index1 = abs(x0) >= C_nulambda_1over2
    x[index0] = ProxL1over2(nu/np.power(Lambda,1/2),x0[index0])
    x[index1] = x0[index1]
    return x


# CL2/3 shrinkage
def ProxL2over3(nu,tau):
    ytilde = np.zeros_like(tau)
    condition = np.abs(tau) > 2*np.power(2*nu/3,3/4)
    t1 = np.sqrt(tau[condition] ** 4 / 256 - 8 * (nu ** 3) / 729)
    t = 2 * (np.power(tau[condition] ** 2 / 16 + t1, 1 / 3) + np.power(tau[condition] ** 2 / 16 - t1, 1 / 3))
    ytilde[condition]=(1/8)*np.sign(tau[condition])*np.power(np.sqrt(t) + np.sqrt(2*np.abs(tau[condition])/np.sqrt(t) -t),3)
    return ytilde

def bisection_CL2over3(a,b,q,nu,Lambda):
    for i in range(20):
        c=(a+b)/2
        if (J(q,nu,Lambda,ProxL2over3(nu/Lambda**q,a),a)-nu)*(J(q,nu,Lambda,ProxL2over3(nu/Lambda**q,c),c)-nu)<0:
            b=c
        else:
            a=c
        if (b-a)<1e-5:
            break
    return c

def shrinkage_CaP2over3(x0,Lambda,nu):
    x = np.zeros((x0.shape[0], 1))
    cnulambda_2over3=2*np.power((2/3)*nu/np.power(Lambda,2/3),3/4)
    C_nulambda_2over3 = bisection_CL2over3(cnulambda_2over3, Lambda + (2 / 3) * nu / Lambda, 2 / 3, nu, Lambda)
    index0 = abs(x0) < C_nulambda_2over3
    index1 = abs(x0) >= C_nulambda_2over3
    x[index0] = ProxL2over3(nu / np.power(Lambda, 2 / 3), x0[index0])
    x[index1] = x0[index1]
    return x


# CL1/4 shrinkage
def Jtauderivative(C,q,tau,t):
    return t+C*q*np.power(t,q-1)-tau

def Bisection_Lq(a_start,b_start,tau,C,q):
    tau_abs = np.abs(tau)   
    a = np.full_like(tau_abs, a_start, dtype=float)
    b = b_start
    for i in range(20):
        c=(a+b)/2
        res_c = Jtauderivative(C, q, tau, c)
        if np.all(np.abs(res_c) < 1e-3):
            break
        res_a = Jtauderivative(C, q, tau, a)
        condition = (res_a * res_c < 0)
        b = np.where(condition, c, b)
        a = np.where(condition, a, c)        
    return c

def ProxL1over4(nu,tau):
    ytilde = np.zeros_like(tau)
    tau_abs = np.abs(tau)
    condition = tau_abs > (7/6)*np.power(3*nu/2,4/7)
    tautilde=np.power(nu*3/16, 4/7)
    if np.any(condition):
        amp = Bisection_Lq(tautilde, tau_abs[condition], tau_abs[condition], nu, 1/4)
        ytilde[condition] = np.sign(tau[condition]) * amp
    return ytilde  

def bisection_CL1over4(a,b,q,nu,Lambda):
    for i in range(20):
        c=(a+b)/2
        if (J(q,nu,Lambda,ProxL1over4(nu/Lambda**q,a),a)-nu)*(J(q,nu,Lambda,ProxL1over4(nu/Lambda**q,c),c)-nu)<0:
            b=c
        else:
            a=c
        if (b-a)<1e-5:
            break 
    return c

def shrinkage_CaP1over4(x0, Lambda, nu):
    x = np.zeros_like(x0)
    cnulambda_1over4 = (7/6)*np.power((3/2)*nu/np.power(Lambda,1/4),4/7) 
    C_nulambda_1over4 = bisection_CL1over4(cnulambda_1over4,Lambda+(1/4)*nu/Lambda,1/4,nu,Lambda)
    index0 = abs(x0) < C_nulambda_1over4
    index1 = abs(x0) >= C_nulambda_1over4
    x[index0] = ProxL1over4(nu / np.power(Lambda, 1 / 4), x0[index0])
    x[index1] = x0[index1]
    return x


# CL1/3 shrinkage
def ProxL1over3(nu,tau):
    ytilde = np.zeros_like(tau)
    tau_abs = np.abs(tau)
    condition = tau_abs > (5/4)*np.power(nu*4/3,3/5)
    tautilde=np.power(2*nu/9,3/5)
    if np.any(condition):
        amp = Bisection_Lq(tautilde, tau_abs[condition], tau_abs[condition], nu, 1/3)
        ytilde[condition]=np.sign(tau[condition]) * amp
    return ytilde

def bisection_CL1over3(a,b,q,nu,Lambda):
    for i in range(20):
        c=(a+b)/2
        if (J(q,nu,Lambda,ProxL1over3(nu/Lambda**q,a),a)-nu)*(J(q,nu,Lambda,ProxL1over3(nu/Lambda**q,c),c)-nu)<0:
            b=c
        else:
            a=c
        if (b-a)<1e-5:
            break 
    return c

def shrinkage_CaP1over3(x0, Lambda, nu):
    x = np.zeros_like(x0)
    cnulambda_1over3 = (5/4)*np.power((4/3)*nu/np.power(Lambda,1/3),3/5)   
    C_nulambda_1over3 = bisection_CL1over3(cnulambda_1over3, Lambda + (1 / 3) * nu / Lambda, 1 / 3, nu, Lambda)
    index0 = abs(x0) < C_nulambda_1over3
    index1 = abs(x0) >= C_nulambda_1over3
    x[index0] = ProxL1over3(nu / np.power(Lambda, 1 / 3), x0[index0])
    x[index1] = x0[index1]
    return x 


# CL3/4 shrinkage
def ProxL3over4(nu,tau):
    ytilde = np.zeros_like(tau)
    tau_abs = np.abs(tau)
    condition = tau_abs > (5/2)*np.power(nu/2,4/5)
    tautilde=np.power(3*nu/16,4/5)
    if np.any(condition):
        amp = Bisection_Lq(tautilde, tau_abs[condition], tau_abs[condition], nu, 3/4)
        ytilde[condition] = np.sign(tau[condition]) * amp
    return ytilde

def bisection_CL3over4(a,b,q,nu,Lambda):
    for i in range(20):
        c=(a+b)/2
        if (J(q,nu,Lambda,ProxL3over4(nu/Lambda**q,a),a)-nu)*(J(q,nu,Lambda,ProxL3over4(nu/Lambda**q,c),c)-nu)<0:
            b=c
        else:
            a=c
        if (b-a)<1e-5:
            break 
    return c

def shrinkage_CaP3over4(x0, Lambda, nu):
    x = np.zeros_like(x0)
    cnulambda_3over4 = (5/2)*np.power(nu/2/np.power(Lambda,3/4),4/5)  
    C_nulambda_3over4 = bisection_CL3over4(cnulambda_3over4, Lambda + (3 / 4) * nu / Lambda, 3 / 4, nu, Lambda)
    index0 = abs(x0) < C_nulambda_3over4
    index1 = abs(x0) >= C_nulambda_3over4
    x[index0] = ProxL3over4(nu / np.power(Lambda, 3 / 4), x0[index0])
    x[index1] = x0[index1]
    return x


# l1/2 shrinkage
def shrinkage_l1over2(x0, a, Lambda):
    x = np.zeros((x0.shape[0], 1))
    threshold = (3 / 2) * np.power(Lambda, 2 / 3)
    index = abs(x0) > threshold
    theta = np.arccos(- np.power(3, 3/2) / 4 * Lambda * np.power(abs(x0[index]), -3/2))
    x[index] = (2 / 3) * x0[index] * (1 + np.cos((2 * theta) / 3))
    return x


# l2/3 shrinkage
def shrinkage_l2over3(x0,a,Lambda):
    x = np.zeros((x0.shape[0], 1))
    threshold = 2 * np.power(2 * Lambda / 3, 3/4)
    index = abs(x0) > threshold
    x0_index = x0[index]
    term1 = np.power(x0_index,2)/16 + np.sqrt(np.power(x0_index,4)/256 - 8*np.power(Lambda,3)/729)
    term2 = np.power(x0_index,2)/16 - np.sqrt(np.power(x0_index,4)/256 - 8*np.power(Lambda,3)/729)
    s = np.power(term1,1/3) + np.power(term2,1/3)
    theta = np.sqrt(2*s) + np.sqrt(2*abs(x0_index) / np.sqrt(2*s) - 2*s)
    x[index] = np.sign(x0_index)*np.power(theta,3)/8
    return x


# l1/4 shrinkage
def shrinkage_l1over4(x0, a, Lambda):
    x = np.zeros_like(x0)
    abs_x0 = abs(x0)
    threshold = (7/6)*np.power(3*Lambda/2,4/7)
    index = abs_x0 > threshold
    tautilde = np.power(Lambda*3/16, 4/7)
    if np.any(index):
        amp = Bisection_Lq(tautilde, abs_x0[index], abs_x0[index], Lambda, 1/4)
        x[index] = np.sign(x0[index]) * amp
    return x


# l1/3 shrinkage
def shrinkage_l1over3(x0, a, Lambda):
    x = np.zeros_like(x0)
    abs_x0 = abs(x0)
    threshold = (5/4)*np.power(4*Lambda/3,3/5)
    index = abs_x0 > threshold
    tautilde = np.power(2*Lambda/9,3/5)
    if np.any(index):
        amp = Bisection_Lq(tautilde, abs_x0[index], abs_x0[index], Lambda, 1/3)
        x[index] = np.sign(x0[index]) * amp
    return x


# l3/4 shrinkage
def shrinkage_l3over4(x0, a, Lambda):    
    x = np.zeros_like(x0)
    abs_x0 = abs(x0)
    threshold = (5/2)*np.power(Lambda/2,4/5)
    index = abs_x0 > threshold
    tautilde = np.power(3*Lambda/16,4/5)
    if np.any(index):
        amp = Bisection_Lq(tautilde, abs_x0[index], abs_x0[index], Lambda, 3/4)
        x[index] = np.sign(x0[index]) * amp
    return x


# l1 shrinkage
def shrinkage_l1(x0, a, Lambda):
    x = np.zeros((x0.shape[0], 1))
    index = abs(x0) > Lambda
    x[index] = np.sign(x0[index]) * (abs(x0[index]) - Lambda)
    return x
