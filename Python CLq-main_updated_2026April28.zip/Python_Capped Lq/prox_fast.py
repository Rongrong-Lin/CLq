import numpy as np
import math


# CL1/2 shrinkage
C_PROX12_CONST = (3 * math.sqrt(3)) / 4 
def J(q,nu,Lambda,u,tau):
    return nu*np.minimum(1.0,np.power(np.abs(u)/Lambda,q)) + 0.5 * (u -tau)**2

def J_scalar(q, nu, Lambda, u, tau):
    """纯标量版本的 J 函数，去除了 NumPy 数组开销"""
    val = abs(u) / Lambda
    # np.minimum 的标量替代
    term1 = val ** q if val < 1.0 else 1.0
    return nu * term1 + 0.5 * (u - tau) ** 2

def ProxL1over2_scalar(nu, tau):
    """纯标量版本的 ProxL1over2，专供二分法使用"""
    abs_tau = abs(tau)
    threshold = 1.5 * (nu ** (2/3))
    if abs_tau > threshold:
        theta = math.acos(-C_PROX12_CONST * nu * (abs_tau ** -1.5))
        return (2 / 3) * tau * (1 + math.cos((2 * theta) / 3))
    return 0.0

def bisection_CL1over2(a, b, q, nu, Lambda):
    """优化后的二分法，减少了 50% 的函数调用"""
    nu_scaled = nu / (Lambda ** q)
    # 缓存端点 a 的函数值，避免在循环中重复计算
    u_a = ProxL1over2_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL1over2_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu 
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc  # 更新缓存的 fa，避免下次重新计算 a
        if (b - a) < 1e-5:
            break     
    return (a + b) / 2

def ProxL1over2_array(nu, tau):
    """优化后的数组版本，供最终矩阵收缩使用"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 1.5 * (nu ** (2/3))
    condition = abs_tau > threshold 
    # 如果没有满足条件的元素，直接返回全零，节省时间
    if not np.any(condition):
        return ytilde 
    tau_cond = tau[condition]
    abs_tau_cond = abs_tau[condition]
    theta = np.arccos(-C_PROX12_CONST * nu * (abs_tau_cond ** -1.5))
    ytilde[condition] = (2 / 3) * tau_cond * (1 + np.cos((2 * theta) / 3))
    return ytilde

def shrinkage_CaP1over2(x0, Lambda, nu):
    x = x0.copy() 
    sqrt_Lambda = math.sqrt(Lambda)
    nu_scaled = nu / sqrt_Lambda
    cnulambda_1over2 = 1.5 * (nu_scaled ** (2/3))
    C_nulambda_1over2 = bisection_CL1over2(cnulambda_1over2, Lambda + 0.5 * nu / Lambda, 0.5, nu, Lambda)
    index0 = np.abs(x0) < C_nulambda_1over2
    x[index0] = ProxL1over2_array(nu_scaled, x0[index0])
    return x


# CL2/3 shrinkage
def real_cbrt(x):
    """实数域下的立方根函数，避免产生复数"""
    return x**(1/3) if x >= 0 else -(-x)**(1/3)

def ProxL2over3_scalar(nu, tau):
    """纯标量版本的 ProxL2over3，用于二分法的高效计算"""
    abs_tau = abs(tau)
    threshold = 2 * ((2 * nu / 3) ** 0.75)
    if abs_tau > threshold:
        tau2 = tau ** 2
        # t1 = sqrt(tau^4/256 - 8*nu^3/729)
        # 注意：在阈值外，根号下理论上始终大于0
        t1 = math.sqrt(max(0, (tau2**2) / 256 - 8 * (nu**3) / 729))
        term_plus = tau2 / 16 + t1
        term_minus = tau2 / 16 - t1
        # 计算 t = 2 * ( (tau^2/16 + t1)^(1/3) + (tau^2/16 - t1)^(1/3) )
        t = 2 * (real_cbrt(term_plus) + real_cbrt(term_minus))  
        sqrt_t = math.sqrt(t)
        # 最终公式
        res = (1/8) * (sqrt_t + math.sqrt(max(0, 2 * abs_tau / sqrt_t - t))) ** 3
        return math.copysign(res, tau)
    return 0.0

def bisection_CL2over3(a, b, q, nu, Lambda):
    """优化后的二分法"""
    nu_scaled = nu / (Lambda ** q)
    # 缓存 fa 减少 50% 计算量
    u_a = ProxL2over3_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL2over3_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc         
        if (b - a) < 1e-5:
            break     
    return (a + b) / 2

def ProxL2over3_array(nu, tau):
    """优化后的数组版本，使用 NumPy 向量化运算"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 2 * ((2 * nu / 3) ** 0.75)
    condition = abs_tau > threshold
    if not np.any(condition):
        return ytilde      
    tau_c = tau[condition]
    abs_tau_c = abs_tau[condition]
    tau2 = tau_c ** 2
    # 向量化计算 t1
    t1 = np.sqrt(np.maximum(0, (tau2**2) / 256 - 8 * (nu**3) / 729))
    tp = tau2 / 16 + t1
    tm = tau2 / 16 - t1
    # NumPy 的 cbrt 专门用于处理实数立方根，比 **(1/3) 更稳健
    t = 2 * (np.cbrt(tp) + np.cbrt(tm))
    sqrt_t = np.sqrt(t)
    # ytilde 计算
    res = (1/8) * (sqrt_t + np.sqrt(np.maximum(0, 2 * abs_tau_c / sqrt_t - t))) ** 3
    ytilde[condition] = np.sign(tau_c) * res
    return ytilde

def shrinkage_CaP2over3(x0, Lambda, nu):
    """优化后的主函数"""
    x = x0.copy()
    q = 2/3
    Lambda_q = Lambda ** q
    nu_scaled = nu / Lambda_q
    # 计算初始搜索范围
    cnulambda_2over3 = 2 * (( (2/3) * nu / Lambda_q ) ** 0.75)
    # 获取二分法计算的算子切换阈值
    C_nulambda = bisection_CL2over3(cnulambda_2over3, Lambda + (2/3) * nu / Lambda, q, nu, Lambda)
    # 执行收缩
    mask = np.abs(x0) < C_nulambda
    if np.any(mask):
        x[mask] = ProxL2over3_array(nu_scaled, x0[mask])
    return x


# CL1/4 shrinkage
def J_derivative_scalar(C, q, tau, t):
    """J_tau(u) 的一阶导数标量版"""
    # t + C*q*t^(q-1) - tau = 0
    return t + C * q * (t ** (q - 1)) - tau

def Bisection_Lq_scalar(tau, C, q, a_start, b_start):
    """标量版二分法：求解单个元素的 Lq Proximal 根"""
    a = a_start
    b = b_start 
    # 预计算 fa
    fa = J_derivative_scalar(C, q, tau, a)
    for _ in range(10):
        c = (a + b) / 2
        fc = J_derivative_scalar(C, q, tau, c)
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc        
        if (b - a) < 1e-5:
            break
    return (a + b) / 2

def ProxL1over4_scalar(nu, tau):
    """标量版 ProxL1over4"""
    abs_tau = abs(tau)
    # L1/4 阈值公式
    threshold = (7/6) * ((1.5 * nu) ** (4/7))
    if abs_tau > threshold:
        # 起始搜索点
        tau_tilde = (nu * 3 / 16) ** (4/7)
        amp = Bisection_Lq_scalar(abs_tau, nu, 0.25, tau_tilde, abs_tau)
        return math.copysign(amp, tau)
    return 0.0

def bisection_CL1over4(a, b, q, nu, Lambda):
    """优化后二分法"""
    nu_scaled = nu / (Lambda ** q)
    u_a = ProxL1over4_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL1over4_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc      
        if (b - a) < 1e-5:
            break
    return (a + b) / 2

def Bisection_Lq_array(tau, C, q, a_start):
    """向量化二分法：一次性处理数组中所有需要求解的根"""
    a = np.full_like(tau, a_start)
    b = tau.copy()
    # 预计算 res_a
    res_a = J_derivative_scalar(C, q, tau, a)
    for _ in range(20):
        c = (a + b) / 2
        res_c = J_derivative_scalar(C, q, tau, c)
        condition = (res_a * res_c < 0)
        # 使用 np.where 更新区间
        b = np.where(condition, c, b)
        a = np.where(condition, a, c)
        res_a = np.where(condition, res_a, res_c)
    return (a + b) / 2

def ProxL1over4_array(nu, tau):
    """优化后的数组版 ProxL1over4"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = (7/6) * ((1.5 * nu) ** (4/7))
    mask = abs_tau > threshold
    if np.any(mask):
        tau_cond = abs_tau[mask]
        tau_tilde = (nu * 3 / 16) ** (4/7)
        # 仅对超过阈值的元素进行向量化二分求解
        amp = Bisection_Lq_array(tau_cond, nu, 0.25, tau_tilde)
        ytilde[mask] = np.sign(tau[mask]) * amp
    return ytilde

def shrinkage_CaP1over4(x0, Lambda, nu):
    x = x0.copy()
    q = 0.25
    Lambda_q = Lambda ** q
    nu_scaled = nu / Lambda_q 
    # 1. 计算外层二分法的搜索起点
    cnulambda_1over4 = (7/6) * ((1.5 * nu_scaled) ** (4/7))
    # 2. 标量二分法求全局阈值
    C_nulambda = bisection_CL1over4(cnulambda_1over4,Lambda + (0.25 * nu / Lambda),q,nu,Lambda)
    # 3. 根据全局阈值过滤并应用向量化 Prox
    index0 = np.abs(x0) < C_nulambda
    if np.any(index0):
        x[index0] = ProxL1over4_array(nu_scaled, x0[index0])
    return x


# CL1/3 shrinkage
def ProxL1over3_scalar(nu, tau):
    """标量版 ProxL1over3，用于外层二分法"""
    abs_tau = abs(tau)
    # 阈值: (5/4) * (4*nu/3)^(3/5)
    threshold = 1.25 * ((nu * 4/3) ** 0.6)
    if abs_tau > threshold:
        # 起始搜索点: (2*nu/9)^(3/5)
        tau_tilde = (2 * nu / 9) ** 0.6
        amp = Bisection_Lq_scalar(abs_tau, nu, 1/3, tau_tilde, abs_tau)
        return math.copysign(amp, tau)
    return 0.0

def bisection_CL1over3(a, b, q, nu, Lambda):
    """外层二分法优化版"""
    nu_scaled = nu / (Lambda ** q)
    u_a = ProxL1over3_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL1over3_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc
        if (b - a) < 1e-5: break
    return (a + b) / 2

def ProxL1over3_array(nu, tau):
    """向量化版 ProxL1over3"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 1.25 * ((nu * 4/3) ** 0.6)
    mask = abs_tau > threshold
    if np.any(mask):
        tau_cond = abs_tau[mask]
        tau_tilde = (2 * nu / 9) ** 0.6
        amp = Bisection_Lq_array(tau_cond, nu, 1/3, tau_tilde)
        ytilde[mask] = np.sign(tau[mask]) * amp
    return ytilde

def shrinkage_CaP1over3(x0, Lambda, nu):
    x = x0.copy()
    q = 1/3
    Lambda_q = Lambda ** q
    nu_scaled = nu / Lambda_q
    # 标量二分求临界阈值
    c_start = 1.25 * ((nu_scaled * 4/3) ** 0.6)
    C_nulambda = bisection_CL1over3(c_start, Lambda + (q * nu / Lambda), q, nu, Lambda)
    index0 = np.abs(x0) < C_nulambda
    if np.any(index0):
        x[index0] = ProxL1over3_array(nu_scaled, x0[index0])
    return x

# CL3/4 shrinkage
def ProxL3over4_scalar(nu, tau):
    """标量版 ProxL3over4"""
    abs_tau = abs(tau)
    # 阈值: (5/2) * (nu/2)^(4/5)
    threshold = 2.5 * ((nu / 2) ** 0.8)
    if abs_tau > threshold:
        # 起始搜索点: (3*nu/16)^(4/5)
        tau_tilde = (3 * nu / 16) ** 0.8
        amp = Bisection_Lq_scalar(abs_tau, nu, 0.75, tau_tilde, abs_tau)
        return math.copysign(amp, tau)
    return 0.0

def bisection_CL3over4(a, b, q, nu, Lambda):
    nu_scaled = nu / (Lambda ** q)
    u_a = ProxL3over4_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL3over4_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc
        if (b - a) < 1e-5: break
    return (a + b) / 2

def ProxL3over4_array(nu, tau):
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 2.5 * ((nu / 2) ** 0.8)
    mask = abs_tau > threshold
    if np.any(mask):
        tau_cond = abs_tau[mask]
        tau_tilde = (3 * nu / 16) ** 0.8
        amp = Bisection_Lq_array(tau_cond, nu, 0.75, tau_tilde)
        ytilde[mask] = np.sign(tau[mask]) * amp
    return ytilde

def shrinkage_CaP3over4(x0, Lambda, nu):
    x = x0.copy()
    q = 0.75
    Lambda_q = Lambda ** q
    nu_scaled = nu / Lambda_q
    c_start = 2.5 * ((nu_scaled / 2) ** 0.8)
    C_nulambda = bisection_CL3over4(c_start, Lambda + (q * nu / Lambda), q, nu, Lambda)
    index0 = np.abs(x0) < C_nulambda
    if np.any(index0):
        x[index0] = ProxL3over4_array(nu_scaled, x0[index0])
    return x
