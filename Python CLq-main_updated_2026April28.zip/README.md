Rongrong Lin, Haitai Yu, Yulan Liu, An Explicit Characterization of  the Proximal Operator of the Capped lq -Norm

