Rongrong Lin, Haitai Yu, Yulan Liu, A Closed-form Formula for the Proximal Operator of the Capped lq -Norm
