import numpy as np
import warnings

warnings.filterwarnings("ignore")


def ISTA(A, b, mu, shrinkage, a, Lambda, maxiter, error):  # mu为步长
    x0 = np.zeros((A.shape[1], 1))
    aa = np.eye(A.shape[1]) - (mu * A.T.dot(A))
    ab = mu * A.T.dot(b)
    for i in range(maxiter):  # 主循环
        x1 = aa.dot(x0) + ab
        x = shrinkage(x1, a, mu*Lambda)
        if (np.linalg.norm(x - x0, 2) / (np.linalg.norm(x) + 1)) < error:
            break
        x0 = x.copy()
    return x, i


def PGAC(A, b, mu, shrinkage, a, Lambda, maxiter, x_true=None):
    """
    带误差记录的PGAC算法
    参数:
        A: 测量矩阵
        b: 观测向量
        mu: 步长
        shrinkage: 临近算子函数
        a: 算子参数
        Lambda: 正则化参数
        maxiter: 最大迭代次数
        x_true: 真实信号(可选，用于计算误差)
    返回:
        x: 恢复的信号
        i: 实际迭代次数
        rel_errors: 每次迭代的相对误差列表(如果提供了x_true)
    """
    x0 = np.zeros((A.shape[1], 1))
    aa = np.eye(A.shape[1]) - (mu * A.T.dot(A))
    ab = mu * A.T.dot(b)
    # 初始化误差记录
    rel_errors = []
    record_error = x_true is not None
    for i in range(maxiter):
        # 梯度步
        x1 = aa.dot(x0) + ab
        # 临近算子步
        x = shrinkage(x1, a, mu * Lambda)
        x0 = x.copy()
        # 记录误差(如果提供了x_true)
        if record_error:
            rel_error = np.linalg.norm(x - x_true) / np.linalg.norm(x_true)
            rel_errors.append(rel_error)
        # 终止条件
        if Lambda < 1e-4:
            break
        # 衰减Lambda
        Lambda = 0.98 * Lambda
    if record_error:
        return x, i, rel_errors
    else:
        return x, i


def iPiano(A, b, rho, beta, alpha, shrinkage, sigma, Lambda, maxiter, error):
    x0 = np.zeros((A.shape[1], 1))
    x1 = np.zeros((A.shape[1], 1))
    aa = (1 + alpha * rho + beta) * np.eye(A.shape[1]) - (alpha * A.T.dot(A))
    ab = alpha * A.T.dot(b)
    for i in range(maxiter):
        y = aa.dot(x1) + ab - beta * x0
        y = y / (1 + alpha * rho)
        x2 = shrinkage(y, sigma, alpha * Lambda)
        # if (np.linalg.norm(x2 - x1, 2) / max(np.linalg.norm(x2), 1)) < error:
        if (np.linalg.norm(x2 - x1, 2) / (np.linalg.norm(x2)+ 1)) < error:
            break
        x0 = x1.copy()
        x1 = x2.copy()
    return x2, i


def DCA1(A, b, rho, beta_k, alpha, shrinkage, sigma, Lambda, maxiter, error):  # beta k序列
    x0 = np.zeros((A.shape[1], 1))
    x1 = np.zeros((A.shape[1], 1))
    aa = np.eye(A.shape[1]) - (alpha * A.T.dot(A))
    ab = alpha * A.T.dot(b)
    ar = alpha * rho
    for i in range(maxiter):  # 主循环
        y = x1 + beta_k[i] * (x1 - x0)
        y = aa.dot(y) + ab + ar * x1
        y = y / (1 + alpha * rho)
        x2 = shrinkage(y, sigma, alpha * Lambda)
        # if (np.linalg.norm(x2 - x1, 2) / max(np.linalg.norm(x2), 1)) < error:
        if (np.linalg.norm(x2 - x1, 2) / (np.linalg.norm(x2)+ 1)) < error:
            break
        x0 = x1.copy()
        x1 = x2.copy()
    return x2, i


def DCA2(A, b, rho, beta_k, alpha, shrinkage_soft, sigma, Lambda, maxiter, error):
    x0 = np.zeros((A.shape[1], 1))
    x1 = np.zeros((A.shape[1], 1))
    aa = np.eye(A.shape[1]) - (alpha * A.T.dot(A))
    ab = alpha * A.T.dot(b)
    lt = alpha * Lambda / sigma
    for i in range(maxiter):  # 主循环
        y = x1 + beta_k[i] * (x1 - x0)
        y = aa.dot(y) + ab + lt * np.sign(x1) * (1 - np.exp(-np.abs(x1) / sigma))
        # y = aa.dot(y) + ab + lt * x1 *(np.exp(-np.abs(x1) / sigma)-1)
        # y = aa.dot(y) + ab + lt * (np.exp(-x1 / sigma) - 1)
        x2 = shrinkage_soft(y, 1, lt)
        # if (np.linalg.norm(x2 - x1, 2) / max(np.linalg.norm(x2), 1)) < error:
        if (np.linalg.norm(x2 - x1, 2) / (np.linalg.norm(x2)+ 1)) < error:
            break
        x0 = x1.copy()
        x1 = x2.copy()
    return x2, i


def F(A, b, x, Lambda, sigma):
    return (np.linalg.norm(A.dot(x) - b, 2) ** 2) / 2 + Lambda * np.sum(1 - np.exp(-np.abs(x) / sigma))


def Accelerated(A, b, ax, ay, shrinkage1, shrinkage2, sigma, Lambda, maxiter, error):
    x0 = np.zeros((A.shape[1], 1))
    x1 = np.zeros((A.shape[1], 1))
    z1 = np.zeros((A.shape[1], 1))
    t1 = 1
    t0 = 0
    axaa = np.eye(A.shape[1]) - ax * (A.T.dot(A))
    axab = ax * (A.T.dot(b))
    ayaa = np.eye(A.shape[1]) - ay * (A.T.dot(A))
    ayab = ay * (A.T.dot(b))

    for i in range(maxiter):  # 主循环
        y = x1 + (t0 / t1) * (z1 - x1) + (t0 - 1) / t1 * (x1 - x0)
        y = ayaa.dot(y) + ayab
        z2 = shrinkage1(y, sigma, ay * Lambda)
        x = axaa.dot(x1) + axab
        v2 = shrinkage2(x, sigma, ax * Lambda)
        t2 = (np.sqrt(4 * t1 ** 2 + 1) + 1) / 2
        x2 = np.where(F(A, b, z2, Lambda, sigma) < F(A, b, v2, Lambda, sigma), z2, v2)
        # if (np.linalg.norm(x2 - x1, 2) / max(np.linalg.norm(x2), 1)) < error:
        if (np.linalg.norm(x2 - x1, 2) / (np.linalg.norm(x2) + 1)) < error:
            break
        x0 = x1.copy()
        x1 = x2.copy()
        z1 = z2.copy()
        t0 = t1
        t1 = t2
    return x2, i

