prox.py---The proximal operator of various penalties

Algo.py---PGAC algorithm

error.py---Convergence behavior of the PGAC for various sparsity-promoting penalties

CappedLq .ipynb---Success rates of the PGAC for various sparsity-promoting penalties

Experiments are conducted via Jupyter Notebook7.2.2 with Python3.11.3 on a PC with an Intel u5 125h CPU 3.6GHz and 24GB RAM.