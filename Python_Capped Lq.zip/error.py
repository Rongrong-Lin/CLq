import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import orth
from scipy.sparse import rand
import time
from prox import *
from Algo import PGAC
# ==================== 参数设置 ====================
m = 256  # 测量数
n = 1024  # 信号维度
k = 51  # 目标稀疏度（非零元素数）
maxiter = 500  # 最大迭代次数
np.random.seed(100)
# ==================== 测量矩阵生成 ====================
print("生成测量矩阵...")
Q = np.random.normal(0, 1, (m, n))
A = orth(Q.T).T
e = np.linalg.eigvals(A @ A.T)
print('最大特征值：', max(e).real)

# ==================== 算子参数设置 ====================
shrinkage_list = [
    shrinkage_CaP1over2,  # 0: CL1/2
    shrinkage_CaP2over3,  # 1：CL2/3
    shrinkage_CaP1,  # 2: CL1
    shrinkage_l1over2, # 3: L1/2
    shrinkage_l2over3, # 4: L2/3
    shrinkage_l1, # 5: L1
    shrinkage_log, # 6: Log
    shrinkage_TL1, # 7: TL1
    shrinkage_scad, # 8: SCAD
    shrinkage_mcp, # 9: MCP
    shrinkage_PiE_soft, # 10: PiE
]

a_list = [  2 ,  2,    1  ,   0  ,  0 ,  0  ,  1  ,  2  , 3.7  , 3.7 ,  2  ]
names = ["CL1/2","CL2/3","CL1","L1/2","L2/3","L1","Log","TL1","SCAD","MCP","PiE"]

# ==================== 生成真实信号 ====================
print("生成稀疏信号...")
sigma = 0.001  # 噪声水平 σ = 0.1% = 0.001
x_true = np.zeros((n, 1))
nonzero_indices = np.random.choice(n, size=k, replace=False)
x_true[nonzero_indices] = np.random.randn(k, 1)  # 非零值为高斯分布
#x_true[x_true != 0] = 2 * x_true[x_true != 0]
epsilon = sigma * np.random.randn(m, 1)
b = A @ x_true + epsilon

# ==================== 记录误差历史 ====================
error_history = {name: [] for name in names}  # 初始化字典存储各算子的误差


# ==================== 主实验循环 ====================
print("运行各算子...")
for i, shrinkage in enumerate(shrinkage_list):
    name = names[i]
    print(f"正在运行{name}...")

    # 初始化变量
    #lamb = 0.1
    lamb = np.linalg.norm(x_true)/(np.sqrt(k) + 1)
    print('lamb:',lamb)
    a = a_list[i]
    mu = 1

    # 特殊算子的条件分支
    if i == 10:  # PiE
        # temp = mu_pie * lambda_list[0] / a_list[0] ** 2
        temp = lamb / a_list[i] ** 2
        if temp <= 1:
            shrinkage = shrinkage_PiE_soft
        else:
            shrinkage = PiEProximalbyLambertWThreshold
    elif i == 6:  # Log
        if np.sqrt(lamb) <= a_list[i]:
            shrinkage = shrinkage_log_soft
        else:
            shrinkage = shrinkage_log_hard

    # 使用PGAC算法
    x_rec, iter_count, rel_errors = PGAC(A, b, mu, shrinkage, a, lamb, maxiter, x_true=x_true)

    # 记录误差
    error_history[name] = rel_errors

# ==================== 绘图 ====================
print("绘制收敛曲线...")
plt.figure(figsize=(12, 8))
color_list = ['orangered','deepskyblue','chocolate','lightgreen','slategrey','blue','deeppink',
              'orange','blueviolet','green','m']
label_list = ["CL1/2","CL2/3","CL1","L1/2","L2/3","L1","Log","TL1","SCAD","MCP","PiE"]
mark_list = ['^','^',None,None,None,None,None,None,None,None,None]
for i, name in enumerate(names):
    if error_history[name]:
            plt.plot(range(len(error_history[name])), error_history[name],
                     color=color_list[i],
                     linewidth=2.5,
                     linestyle='--',
                     marker=mark_list[i],
                     markersize=12 if mark_list[i] else 0,
                     markevery=0.1,
                     label=label_list[i])

plt.yscale('log')
plt.xlabel('Iteration', fontsize=14)
plt.ylabel('Relative Error', fontsize=14)
plt.legend(fontsize=12, loc='upper right')
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.tight_layout()

# 保存图像
#timestamp = time.strftime("%Y%m%d-%H%M%S")
plt.savefig(f'sparsity=five_percent.png', dpi=300, bbox_inches='tight')
plt.show()
